# giamdalessandro.github.io

Personal website, available [here](https://giamdalessandro.github.io/).


### References
- This website is based on [Jekyll](https://jekyllrb.com/) and theme [Prologue](https://jekyll-themes.com/prologue/).